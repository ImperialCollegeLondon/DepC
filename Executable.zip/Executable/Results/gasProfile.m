DateLegend = {'PB-P' 'Sg' 'Sw'};
gasSaturation = [