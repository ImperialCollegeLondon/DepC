DateLegend = {'PB-P' 'BubblesNumber' 'WaterClusters'};
bubbleNumbers = [