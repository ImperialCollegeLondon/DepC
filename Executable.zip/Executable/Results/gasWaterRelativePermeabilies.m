DataLegend = {'Sw' 'Krw' 'Krg'};
Depletion_relPerm = [